<?php

return array(
    'host' => getenv('SANDWORTH_DB_HOST') ? getenv('SANDWORTH_DB_HOST') : '127.0.0.1',
    'port' => getenv('SANDWORTH_DB_PORT') ? getenv('SANDWORTH_DB_PORT') : '3306',
    'database' => getenv('SANDWORTH_DB_NAME') ? getenv('SANDWORTH_DB_NAME') : 'sandworth_zillow',
    'username' => getenv('SANDWORTH_DB_USER') ? getenv('SANDWORTH_DB_USER') : 'root',
    'password' => getenv('SANDWORTH_DB_PASS') ? getenv('SANDWORTH_DB_PASS') : '',
    'charset' => 'utf8mb4',
);
